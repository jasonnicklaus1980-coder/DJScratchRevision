# DJ Scratch 1.6

A turntable front end for the MPC that plays **whatever is coming in, live**: an MPC input, a track, a pad, a submix or the
master. Scratch it, stop it, spin it back up, pitch it, reverse it, loop it, and let the **MPC's own Sampler** record the
result. Or put a sample on the platter and scratch that over your beat. DJ Scratch is not a recorder: it never writes audio
files. A native MPC OS VST2 **insert effect** with a
four-page touchscreen skin (an original ScratchLab "DD-One" deck design).

## Requirements
- A first-generation MPC OS standalone device (32-bit ARM: MPC X, Live / Live II, One, Key 61, Force).
- **Root shell access** (SSH). Installing plugins this way is unofficial: back up first, use at your own risk.

## Build and install from your computer (no GitHub)
On Ubuntu/Debian/Linux Mint, on Windows inside WSL (Ubuntu), or on any Mac/PC with Docker Desktop, in the project folder:

    ./scripts/build_mpc.sh <mpc-ip>

It builds the ARM plugin (installing the cross-compiler with apt if needed, or using Docker), checks the binary is something a
Gen1 MPC can load, packages `dist/DJScratch-1.4.0-mpc-armv7.zip`, copies it to the MPC over SSH and runs the installer.
Leave out the IP to only build. To install from a phone instead, upload `dist/DJScratch-1.4.0-mpc-armv7.zip` and `dist/setup.sh`
to `/tmp` with Terminus and run `sh /tmp/setup.sh`. (GITHUB.md describes building on GitHub, if you'd rather not use a computer.)

## Install (from an already built package)
1. From your computer: `scp -r DJScratch-1.4.0 root@<device-ip>:/tmp/`  (or `scripts/deploy.sh <device-ip>`)
2. `ssh root@<device-ip> sh /tmp/DJScratch-1.4.0/install.sh`

The installer copies `djscratch.so` to `/sdcard/vst/` and the skin to `/sdcard/Synths/ScratchLab - VST - DJ Scratch/`,
makes the folder **Internal > DJ Scratch > Samples**, **stops MPC** (save your project first), backs up
`MPC.settings`, adds the plugin to the plugin list and starts MPC again. Re-running upgrades in place. Add `-y` to skip the
confirmation.

**MPC One / Live:** if the plugin does not load from the SD card (it can be mounted `noexec` there), install the `.so`
on the internal drive instead: `sh install.sh -t /media/az01-internal/vst` (and the same `-t` for `uninstall.sh`).

## Sample your performance with the MPC Sampler (the main workflow)
The MPC's Sampler has its own **INSERTS**. Put DJ Scratch there and the Sampler records the deck's **output**: every scratch,
fader cut, brake, backspin, reverse, pitch change, loop roll and transformer gate, exactly as you hear it.

    MPC input > DJ Scratch (in the Sampler's INSERTS) > the MPC Sampler > a new sample on a pad

1. Press **SAMPLER**. Set the input (e.g. **Input 1,2**, **Stereo**).
2. In **INSERTS**, add **DJ Scratch**. Tap it to open the deck. The status line says **LIVE IN -xx dB**.
3. Set the Sampler's threshold and mode (PAD TAP / PAD HOLD, max length) as usual.
4. Hit a pad to start sampling, perform on the deck (drag the record, Q-Links, keys), hit the pad to stop.
5. The new sample on that pad is your performance. If the fader is closed, the sample is silent there.

Turn the Sampler's **monitor** on to hear the deck while you play. Threshold, length, punch and assigning the sample to a pad
are all the MPC Sampler's own. What you hear from the insert is what gets recorded.
Keep **MIDI NOTES** off (the default): in PAD TAP mode the pad you hit to sample is also sent to the insert as a note.

## Playing the deck on a track
To just play the deck (no sampling), put DJ Scratch in an insert of an **audio track** whose input is your source, with input
monitoring on. (Any insert works the same way: a pad, a program, a submix or the master.) The plugin is completely transparent
until you touch it, so you hear the source exactly as it comes in.

## The deck (DECK page)
The plugin always keeps the last seconds of incoming audio (the **history**). The record is a needle on that history.
**History** (SAMPLE page: 10, 20, 40 or 60 s) sets how far back you can scratch, reverse and loop; more history uses more memory
(20 s at 48 kHz is about 8 MB, 60 s about 34 MB). Changing it starts the history over.

- **Drag the record** on the screen (straight up and down anywhere on it), or turn **Q-Link 1**: the needle follows your
  hand like a real record. Back = backwards,
  forward = forwards, at the speed you move. Hold still and the record is silent.
- **START STOP**: the motor. Stop it and the incoming audio winds down to a halt like a turntable switched off. Start it and
  the record spins back up from where it stopped, then returns to the live signal (see Release, below).
  **Start** and **Stop** set how long the motor takes (0.1 to 4 s up, 0.1 to 8 s down): short for a tight DJ deck, long for a
  slow, heavy wind-down.
- **BRAKE**: a hard stop (0.12 s), whatever Stop is set to.
- **PITCH** fader (Q-Link 2): **Range** +/-8, +/-16 or +/-50 %, **Fine** +/-1 %, **RESET** puts both back to 0.
  **Pitch Mode** (under Range): **SHIFT** (default) changes the pitch of the live input instantly, up or down, and the sound
  stays in time with what comes in (like an SP-1200 on the Sampler input; about 25 ms of delay while pitched, none at 0 %).
  **VINYL** is a real record: pitch is speed, so pitched down it falls behind the live signal and pitched up it can only
  catch up with "now". On a loaded sample (SAMPLE source) pitch is always vinyl.
  **BEND** (Q-Link 3) is a nudge of up to +/-4 % that springs back when you let go, like pushing the platter edge.
- **45 RPM**: 1.35x speed. **REVERSE**: plays the history backwards.
- **The record label turns with the audio**: at normal speed, slower when pitched down, it stops when you brake and runs
  backwards in reverse. **INPUT** shows the level coming in.

**What VINYL pitch means on live audio.** A record can't play the future. Pitched **down**, the deck plays slower and falls behind
the live signal (the display says how far, e.g. "PITCH -6.0 %  0.84 s behind"). Pitched **up**, it catches up with the live
signal and then stays on it. Put the pitch back to 0 and the deck returns to the live signal. This is a turntable (speed and
pitch move together); there is no key lock. On a loaded sample (SAMPLE source) pitch works exactly like a record.

**Release** (SETUP page): *Slip* = when the record is back at speed it jumps to the live signal, as if the beat kept running
under your hand. *Catch up* = it races forward to the live signal instead. On a loaded sample, *Catch up* means **vinyl**: the
record starts again from where your hand left it.

If you let go of the record while the motor is stopped or pitched, the record goes back to the motor through the slipmat:
stopped stays stopped; pitched carries on at that pitch.

**The record turns** with everything that moves it: the motor, pitch, 45, reverse, backspin, loops, and your hand. Drag
up/down on the platter or turn Q-Link 1 and the label turns as far as the audio moves (0.2 s of audio = a ninth of a turn,
like a real 33 1/3 record).

**LOOP ROLL** keys (1/4, 1/8, 1/16, 1/32): press one and the deck repeats the last note value at the MPC tempo; press another
to roll (the first one goes out); press the lit one again to drop back into the music. **LOOP** loops the Note Value set on
the GROOVE page (1/32 to 1 bar, triplets too; Q-Link 8 and 9 on the DECK page).

**TRANSFORMER** (ON, rate, pattern, open): a tempo-synced gate that chops the sound, locked to the MPC's beat position. Rate
1/4 to 1/32 (triplets too), pattern Straight / Offbeat / Gallop / Syncopated, Open = how much of each step plays. It works on
everything: live audio, a scratch, a loop roll. Loop + transformer together is the classic stutter-cut.

**Also on the DECK page:** HOLD (keep your hand on the record), AUTO (moving the platter grabs the record, and it lets go after
Auto Release), BACKSPIN, CHOP, FADER, LOOP, the INPUT meter, the pitch range and the pitch mode. Start/stop times, fine pitch, bend and 45 are
also on the SETUP page.

### Q-Links
| Page | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| DECK | Platter | Pitch | Bend | Start/Stop | Brake | Backspin | Reverse | Loop | Note value | Transformer | Gate rate | Hold |
| GROOVE | Loop | Note value | Tempo | Transformer | Rate | Open | Pattern | Hold | Backspin | Chop | Fader | Output |
| SAMPLE | Platter | Source | Sample | Cue | Thru | Rescan | Start/Stop | Backspin | Chop | Fader | History | Output |
| SETUP | Start time | Stop time | Fine | Bend | Release | Catch-up speed | Spin speed | Spin time | Throw | Inertia | Output | Bypass |

For the most "real deck" feel: Q-Link 1 is the record (turn it like a jog wheel; it re-centres itself when you let go, so
there's always room both ways), Q-Link 2 is the pitch fader, Q-Link 3 nudges, Q-Link 4 is the start/stop button and Q-Link 5
the brake. **Throw** sets how much audio one full turn of the platter control covers; **Inertia** how heavy the platter feels.

## Scratch tools
- **BACKSPIN** (tap): the record spins backwards at **Spin Speed** and slows to a stop over **Spin Time**, then returns.
- **FADER** (latched): the crossfader: closed = muted. **CHOP** (tap) flips it for **Chop Length**. Tap CHOP in rhythm with
  FADER closed for transform scratches.
- **LOOP ROLL** keys and **LOOP** (latched): repeat the last note value at the MPC tempo (see the DECK page above).
- **TRANSFORMER** (DECK and GROOVE pages): the tempo-synced gate (Rate, Open %, Pattern).
- **Tempo**: the plugin follows the MPC tempo; if the MPC doesn't report one the display says "(default)" and it uses 120 BPM.
  Set **Tempo** on the GROOVE page to override.
- **MIDI notes** (off by default; turn on **MIDI NOTES** on the SETUP page): C..G# hold a loop of 1/32..1 bar, A backspin,
  A# chop, B transformer on/off. Off, the pads and the sequence never trigger the deck.
- **Your hand always wins:** touch the record during a loop and you scratch from where the loop was playing; the loop keys go
  out. A loop key pressed while you hold the record starts when you let go.

## Scratch a sample (SAMPLE source)
1. Copy WAVs into **Internal > DJ Scratch > Samples** (any rate, 8/16/24/32-bit or float, mono or stereo; the first 90 s).
2. SAMPLE page: **Source** = *Sample*, turn **Sample** to pick a file. New files appear within 2 s, or tap **RESCAN**.
3. The motor, pitch, 45, reverse, brake and every scratch tool work on it. **CUE** drops the needle at the start.
4. **THRU** lets the incoming audio pass underneath untouched, so you scratch the sample over the beat. FADER, CHOP,
   TRANSFORMER and Output act on the sample only.

To scratch a sample you made in the MPC, export it as a WAV into the Samples folder.

## Presets
17 presets (the plugin's programs) set the scratch feel and the gate: Classic Scratch, Tight Wrist, Heavy Platter, Long Throw,
Slip Mode, Catch Up, Manual Grab, Hand Transformer, Hard Backspin, Soft Backspin, Auto Transformer, Gallop Gate, Syncopated Gate,
Triplet Cut, Loop 1/8, Loop 1/16, Loop 1/4. They never change the motor, pitch or the sample settings, never turn LOOP on,
and keep your Tempo.

## What a plugin on the MPC can and can't do
Built and tested: live input through the history buffer, scratch, motor start/stop/brake with adjustable times, pitch with
three ranges plus fine and bend (real-time pitch shift or vinyl), 33/45, reverse, cue (sample source), loop, backspin, fader
and chop, transformer, tempo and beat position from the MPC, input meter, the turning record. Sampling is done by the MPC's
own Sampler, recording the deck's output from its INSERTS.

Not possible from an MPC plugin (the VST2 interface has no way to do these): create samples, programs or tracks inside the
MPC; assign a sample to a pad; know the selected track, program or pad; trigger pads; choose the MPC's audio input (set it
on the track); multi-touch (the MPC skin system gives one touch at a time); draw a live waveform (the skin system only shows
fixed images moved by parameter values, which is how the record and the meter work). MIDI **output** from an insert effect
and MIDI **input** to one are not confirmed on the MPC.

Not in this version: a second deck with a crossfader, key lock (time-stretch), BPM/key detection, MIDI learn, hot cues,
slicing onto 16/32 pads. For chopping, use the MPC's own Sample Edit Chop mode on the sample: it slices to pads far better
than a plugin could.

## Uninstall
`ssh root@<device-ip> sh /tmp/DJScratch-1.4.0/uninstall.sh` removes the plugin, its skin and the plugin-list entry. Your
`DJ Scratch` folder (your samples) is left alone.

## Troubleshooting
- Plugin does not appear: it is not listed until MPC restarts. Check `grep djscratch /media/az01-internal/Settings/*/MPC.settings`.
- MPC crashes on load: run `uninstall.sh`, or restore the `MPC.settings.bak-djscratch-*` backup and delete `/sdcard/vst/djscratch.so`.
- Plain parameter list instead of the skin: MPC looks for `/sdcard/Synths/<manufacturer> - VST - <plugin>`, here
  `ScratchLab - VST - DJ Scratch`. Check `/sdcard/Synths` is in MPC's SynthContentLocations; a skin-only change needs no restart,
  just remove and re-insert the plugin.
- The record doesn't turn on screen, or the meter doesn't move: the MPC may not redraw a plugin's read-outs while you watch.
  The audio is unaffected; please report it.
- Nothing to scratch / "play some audio first": the plugin only knows audio that has passed through it since you inserted it.
- No sound from the deck in the Sampler: turn the MPC Sampler's **monitor** on.
- "no DJ Scratch folder on the drive": create it: `mkdir -p "/media/az01-internal/DJ Scratch/Samples"`.
- "CAN'T LOAD name: unsupported WAV format": re-save the file as 16 or 24-bit PCM WAV.
