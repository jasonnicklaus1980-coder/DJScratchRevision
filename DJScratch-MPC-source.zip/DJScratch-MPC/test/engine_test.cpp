// Engine tests (no host needed). Built with ASan + UBSan, so any ring-buffer overrun fails loudly.
// Input is a rising ramp x[n] = n * 1e-6 (so "which sample is this?" is readable from the output value) or a sine.
#include "scratch/Scratch.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>

using namespace ds;
static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { ++checks; if (! (cond)) { ++fails; std::printf ("  FAIL line %d: %s  ", __LINE__, #cond); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)

static const double SR = 44100.0;
static const int BLK = 128;

struct Rig
{
    Engine e; Settings s; long t = 0; std::vector<float> in, out; bool ppqSync = false;
    Rig() { e.prepare (SR); in.resize (BLK); out.resize (BLK); }
    // run `frames` frames, input = ramp; returns the last output sample. The optional callback sees every output sample.
    template <class F> void run (long frames, F f)
    {
        while (frames > 0)
        {
            const int n = frames < BLK ? (int) frames : BLK;
            if (ppqSync) { s.ppqValid = true; s.ppq = (double) t / SR * s.bpm / 60.0; }
            for (int i = 0; i < n; ++i) in[i] = (float) ((t + i) * 1e-6);
            e.process (in.data(), in.data(), out.data(), out.data() + 0, n, s);   // L and R share one buffer: harmless, same data
            for (int i = 0; i < n; ++i) f (t + i, in[i], out[i]);
            t += n; frames -= n;
        }
    }
    void run (long frames) { run (frames, [] (long, float, float) {}); }
};

static void testPassthrough()
{
    std::printf ("passthrough\n");
    Rig r; r.s.autoGrab = true;
    int bad = 0;
    r.run (SR * 2, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (bad == 0, "%d samples differ from the input while idle", bad);
    CHECK (r.e.state() == Engine::LIVE, "state");
}

static void testSilenceWhenHeld()
{
    std::printf ("held record is silent\n");
    Rig r; r.s.hold = true;
    r.run (SR * 0.5);
    float peak = 0;
    r.run (SR * 0.5, [&] (long, float, float out) { peak = std::fmax (peak, std::fabs (out)); });
    CHECK (r.e.state() == Engine::GRAB, "state %d", (int) r.e.state());
    CHECK (peak < 1e-5f, "peak %g while stopped (the ramp input is ~0.02-0.09)", (double) peak);
}

static void testBackAndForth()
{
    std::printf ("moving the platter back plays the past backwards, forward plays it forwards\n");
    Rig r; r.s.autoGrab = true; r.s.throwSec = 1.0f; r.s.inertiaMs = 6.f;
    r.run (SR * 2);                              // fill history
    // move the platter back 0.1 (= 0.1 s of audio) over ~100 ms, in 10 steps like a hand would
    long tStart = r.t;
    float p = 0.5f;
    std::vector<float> o;
    for (int step = 0; step < 10; ++step)
    {
        p -= 0.01f; r.s.platter = p;
        r.run (BLK * 4, [&] (long, float, float out) { o.push_back (out); });
    }
    // while moving backwards the ramp output must be decreasing (reading earlier samples)
    int dec = 0, inc = 0;
    for (size_t i = 1; i < o.size(); ++i) { if (o[i] < o[i - 1] - 1e-9f) ++dec; else if (o[i] > o[i - 1] + 1e-9f) ++inc; }
    CHECK (dec > inc * 5, "decreasing %d vs increasing %d", dec, inc);
    // head ends about 0.1 s behind where it was at tStart: compare with ramp
    const float expect = (float) ((tStart) * 1e-6) - 0.1f * 0.0441f;    // (sample index) * 1e-6, 0.1 s = 4410 frames
    (void) expect;
    CHECK (r.e.state() == Engine::GRAB, "state");
    CHECK (r.e.behindSec() > 0.05f && r.e.behindSec() < 0.35f, "behind %g s", (double) r.e.behindSec());
    // now forward 0.05 back toward live: output must increase
    o.clear();
    for (int step = 0; step < 5; ++step) { p += 0.01f; r.s.platter = p; r.run (BLK * 4, [&] (long, float, float out) { o.push_back (out); }); }
    dec = inc = 0;
    for (size_t i = 1; i < o.size(); ++i) { if (o[i] < o[i - 1] - 1e-9f) ++dec; else if (o[i] > o[i - 1] + 1e-9f) ++inc; }
    CHECK (inc > dec * 5, "increasing %d vs decreasing %d", inc, dec);
}

static void testSlipReturn()
{
    std::printf ("slip: lets go -> back to bit-exact live\n");
    Rig r; r.s.returnMode = 0; r.s.releaseSec = 0.2f;
    r.run (SR);
    r.s.platter = 0.45f; r.run (SR * 0.1);
    CHECK (r.e.state() == Engine::GRAB, "state %d", (int) r.e.state());
    r.run (SR * 0.5);                            // still -> after releaseSec it lets go
    int bad = 0; float lastDiff = 0;
    r.run (SR * 0.2, [&] (long, float in, float out) { if (in != out) { ++bad; lastDiff = out - in; } });
    CHECK (r.e.state() == Engine::LIVE, "state %d", (int) r.e.state());
    CHECK (bad == 0, "%d samples differ after returning (last diff %g)", bad, (double) lastDiff);
    CHECK (std::fabs (r.s.platter - 0.45f) < 1e-6f, "engine must not change the settings struct");
}

static void testCatchUp()
{
    std::printf ("catch up: output races forward then lands on live\n");
    Rig r; r.s.returnMode = 1; r.s.catchSpeed = 3.f; r.s.releaseSec = 0.15f;
    r.run (SR);
    r.s.platter = 0.30f; r.run (SR * 0.15);      // ~0.2 s back
    const float back0 = r.e.behindSec();
    CHECK (back0 > 0.1f, "behind %g", (double) back0);
    bool sawReturn = false;
    r.run (SR * 0.9, [&] (long, float, float) { if (r.e.state() == Engine::RETURN) sawReturn = true; });   // let go
    CHECK (sawReturn, "never entered RETURN");
    r.run (SR * 0.3);
    int bad = 0;
    r.run (SR * 0.1, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (r.e.state() == Engine::LIVE, "state %d", (int) r.e.state());
    CHECK (bad == 0, "%d samples differ once caught up", bad);
}

static void testBackspin()
{
    std::printf ("backspin\n");
    Rig r; r.s.spinSpeed = 8.f; r.s.spinSec = 1.0f; r.s.returnMode = 0;
    r.run (SR * 3);
    r.e.triggerBackspin();
    std::vector<float> o; bool sawSpin = false; float minVel = 0;
    r.run (SR * 1.5, [&] (long, float, float out) { o.push_back (out); if (r.e.state() == Engine::SPIN) { sawSpin = true; minVel = std::fmin (minVel, r.e.velocity()); } });
    CHECK (sawSpin, "never spun");
    CHECK (minVel < -4.f, "start velocity only %g", (double) minVel);
    int dec = 0, inc = 0;
    for (size_t i = 1; i < 4000 && i < o.size(); ++i) { if (o[i] < o[i - 1]) ++dec; else if (o[i] > o[i - 1]) ++inc; }
    CHECK (dec > inc * 5, "first 90 ms should play backwards: dec %d inc %d", dec, inc);
    r.run (SR * 0.5);
    int bad = 0;
    r.run (SR * 0.1, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (r.e.state() == Engine::LIVE && bad == 0, "state %d, %d differ", (int) r.e.state(), bad);
}

static void testChopAndFader()
{
    std::printf ("chop / fader\n");
    Rig r; r.s.chopMs = 50.f; r.s.cutMs = 1.f;
    r.run (SR * 0.5);
    r.e.triggerChop();
    float minAbs = 1e9f; long muted = 0;
    r.run (SR * 0.2, [&] (long, float, float out) { if (std::fabs (out) < 1e-9f) ++muted; minAbs = std::fmin (minAbs, std::fabs (out)); });
    const double ms = muted / SR * 1000.0;
    CHECK (ms > 40 && ms < 56, "muted for %.1f ms, expected ~50 minus fades", ms);
    int bad = 0;
    r.run (SR * 0.1, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (bad == 0, "not back to pass-through after the chop (%d)", bad);
    // closed fader + chop = a short open blip (transform)
    r.s.faderClosed = true; r.run (SR * 0.1);
    r.e.triggerChop(); long open = 0;
    r.run (SR * 0.2, [&] (long, float, float out) { if (std::fabs (out) > 1e-4f) ++open; });
    CHECK (open / SR * 1000.0 > 35, "open for %.1f ms", open / SR * 1000.0);
}

static void testBoundsAndFinite()
{
    std::printf ("extreme gestures stay finite and inside the ring (ASan would flag overruns)\n");
    Rig r; r.s.inertiaMs = 3.f; r.s.throwSec = 4.f; r.s.returnMode = 1;
    uint32_t rng = 12345; bool finite = true; float peak = 0;
    for (int blk = 0; blk < 4000; ++blk)
    {
        rng = rng * 1664525u + 1013904223u;
        if ((rng >> 24) < 60) r.s.platter = (float) ((rng >> 8) & 0xffff) / 65535.f;
        if ((rng >> 20) % 97 == 0) r.e.triggerBackspin();
        if ((rng >> 20) % 89 == 0) r.e.triggerChop();
        if ((rng >> 20) % 211 == 0) r.s.hold = ! r.s.hold;
        if ((rng >> 20) % 301 == 0) r.s.returnMode = 1 - r.s.returnMode;
        if ((rng >> 20) % 173 == 0) { r.s.loopOn = ! r.s.loopOn; r.s.loopBeats = (double) (1 + (rng >> 4) % 16) * 0.125; r.s.bpm = 40.0 + (double) ((rng >> 9) % 200); }
        if ((rng >> 20) % 131 == 0) { r.s.tOn = ! r.s.tOn; r.s.tMask = (rng >> 3) & 0xFFFF; r.s.tStepBeats = 0.125 * (double) (1 + (rng >> 11) % 8); }
        if ((rng >> 20) % 499 == 0) r.s.bypass = ! r.s.bypass;
        r.run (BLK, [&] (long, float, float out) { if (! std::isfinite (out)) finite = false; peak = std::fmax (peak, std::fabs (out)); });
    }
    CHECK (finite, "non-finite output");
    CHECK (peak < 1.5f, "peak %g", (double) peak);
}


static void testLoop()
{
    std::printf("loop by note value\n");
    Rig r; r.s.bpm = 120; r.s.loopBeats = 0.25;               // 1/16 note at 120 BPM = 0.125 s
    const long L = (long) std::llround (0.25 * 60.0 / 120.0 * SR);
    r.run (SR * 2);
    r.s.loopOn = true;
    std::vector<float> o; r.run (SR * 1, [&] (long, float, float out) { o.push_back (out); });
    CHECK (r.e.state() == Engine::LOOP, "state %d", (int) r.e.state());
    CHECK (std::fabs (r.e.loopSec() - 0.125f) < 0.001f, "loop %.4f s", (double) r.e.loopSec());
    // after the 5 ms fade-in: periodic with period L, and every value comes from the last L frames before the press
    const float lo = (float) ((2 * SR - L - 200) * 1e-6), hi = (float) ((2 * SR) * 1e-6);
    int notPeriodic = 0, outOfRange = 0; float maxJump = 0;
    for (size_t i = 600; i + L < o.size(); ++i) { if (std::fabs (o[i] - o[i + L]) > 1e-7f) ++notPeriodic; }
    for (size_t i = 600; i < o.size(); ++i) { if (o[i] < lo || o[i] > hi) ++outOfRange; if (i > 600) maxJump = std::fmax (maxJump, std::fabs (o[i] - o[i - 1])); }
    CHECK (notPeriodic == 0, "%d samples differ from one loop earlier", notPeriodic);
    CHECK (outOfRange == 0, "%d samples outside the captured window", outOfRange);
    // wrap is crossfaded (the ramp's loop wrap is a big step otherwise: L * 1e-6)
    CHECK (maxJump < 0.5f * (float) (L * 1e-6), "wrap jump %.5f vs raw step %.5f", (double) maxJump, (double) (L * 1e-6));
    // release: back to bit-exact live
    r.s.loopOn = false; r.run (SR * 0.1);
    int bad = 0; r.run (SR * 0.2, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (r.e.state() == Engine::LIVE && bad == 0, "state %d, %d samples differ after release", (int) r.e.state(), bad);
    // changing the note value while looping re-captures a different length of the same audio
    r.s.loopOn = true; r.s.loopBeats = 0.5; r.run (SR * 0.2);
    CHECK (std::fabs (r.e.loopSec() - 0.25f) < 0.001f, "1/8 note loop %.4f s", (double) r.e.loopSec());
    r.s.loopBeats = 1.0 / 3.0; r.run (SR * 0.2);
    CHECK (std::fabs (r.e.loopSec() - 0.1667f) < 0.002f, "1/8 triplet loop %.4f s", (double) r.e.loopSec());
    r.s.loopOn = false; r.run (SR * 0.3);
    // tempo scales the length
    r.s.bpm = 60; r.s.loopBeats = 1.0; r.s.loopOn = true; r.run (SR * 0.2);
    CHECK (std::fabs (r.e.loopSec() - 1.0f) < 0.002f, "1/4 note at 60 BPM = %.4f s", (double) r.e.loopSec());
    r.s.loopOn = false; r.run (SR * 0.3);
    // not enough audio yet: refuses, stays live and transparent
    Rig q; q.s.bpm = 120; q.s.loopBeats = 4.0; q.run (SR * 0.05); q.s.loopOn = true;
    int bad2 = 0; q.run (SR * 0.1, [&] (long, float in, float out) { if (in != out) ++bad2; });
    CHECK (q.e.state() == Engine::LIVE && q.e.loopFailed() && bad2 == 0, "short history: state %d failed %d differ %d", (int) q.e.state(), (int) q.e.loopFailed(), bad2);
    // the hand wins: a loop asked for mid-scratch waits until the hand lets go; moving the platter during a loop takes over
    Rig u; u.s.bpm = 120; u.s.loopBeats = 0.5; u.s.releaseSec = 0.2f; u.run (SR);
    u.s.platter = 0.4f; u.run (SR * 0.1); u.s.loopOn = true; u.run (SR * 0.1);
    CHECK (u.e.state() == Engine::GRAB, "loop pressed while scratching: the hand keeps the record (state %d)", (int) u.e.state());
    u.run (SR * 0.3);
    CHECK (u.e.state() == Engine::LOOP, "hand lets go: the loop starts (state %d)", (int) u.e.state());
    u.e.triggerBackspin(); u.run (SR * 0.2);
    CHECK (u.e.state() == Engine::LOOP, "backspin ignored while looping: state %d", (int) u.e.state());
    // recording is frozen during a loop: after release the history continues from where the loop started
    u.s.loopOn = false; u.run (SR * 0.5);
    CHECK (u.e.state() != Engine::LOOP, "state %d", (int) u.e.state());
}

static void testTransformer()
{
    std::printf("transformer gate\n");
    // straight 1/16 at 120 BPM, 50 % duty, free-running: steps of 125 ms, open for the first half of each
    Rig r; r.s.bpm = 120; r.s.tOn = true; r.s.tStepBeats = 0.25; r.s.tDuty = 0.5f; r.s.tMask = 0xFFFF; r.s.cutMs = 0.5f;
    r.run (SR * 0.5);
    std::vector<float> o; r.run (SR * 2, [&] (long, float, float out) { o.push_back (out); });
    long open = 0; for (float x : o) if (std::fabs (x) > 1e-9f) ++open;
    CHECK (std::fabs ((double) open / (double) o.size() - 0.5) < 0.04, "open %.1f %% (expected ~50)", 100.0 * (double) open / (double) o.size());
    // gate edges are 62.5 ms apart (to within the 0.5 ms fade)
    std::vector<long> edges; bool was = false;
    for (size_t i = 0; i < o.size(); ++i) { const bool on = std::fabs (o[i]) > 1e-9f; if (on != was) { edges.push_back ((long) i); was = on; } }
    int badGap = 0; for (size_t k = 2; k + 1 < edges.size(); ++k) if (std::labs ((edges[k] - edges[k - 1]) - (long) (0.0625 * SR)) > 80) ++badGap;
    CHECK (edges.size() > 25 && badGap == 0, "%zu edges, %d irregular", edges.size(), badGap);
    // offbeat pattern with duty 100 %: odd steps only, half the time, period of two steps
    Rig p; p.s.bpm = 120; p.s.tOn = true; p.s.tStepBeats = 0.25; p.s.tDuty = 1.f; p.s.tMask = 0xAAAA; p.s.cutMs = 0.5f;
    p.run (SR * 0.5); o.clear(); p.run (SR * 2, [&] (long, float, float out) { o.push_back (out); });
    open = 0; for (float x : o) if (std::fabs (x) > 1e-9f) ++open;
    CHECK (std::fabs ((double) open / (double) o.size() - 0.5) < 0.03, "offbeat open %.1f %%", 100.0 * (double) open / (double) o.size());
    // locked to host position: gate follows ppq, whatever happened before
    Rig h; h.s.bpm = 120; h.s.tOn = true; h.s.tStepBeats = 0.5; h.s.tDuty = 0.5f; h.s.tMask = 0xFFFF; h.s.cutMs = 0.5f; h.ppqSync = true;
    h.run (SR * 0.37);   // arbitrary start
    long agree = 0, total = 0;
    h.run (SR * 2, [&] (long t, float, float out) {
        const double beat = (double) t / SR * 2.0; const double fr = beat / 0.5 - std::floor (beat / 0.5);
        if (fr > 0.02 && fr < 0.48 && t > 100) { ++total; if (std::fabs (out) > 1e-9f) ++agree; }
        if (fr > 0.52 && fr < 0.98 && t > 100) { ++total; if (std::fabs (out) < 1e-9f) ++agree; }
    });
    CHECK (total > 50000 && agree == total, "ppq lock: %ld of %ld samples as expected", agree, total);
    // off: exact pass-through; bypass beats the gate
    Rig q; q.s.tOn = false; int bad = 0; q.run (SR, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (bad == 0, "gate off is transparent (%d)", bad);
    Rig b; b.s.tOn = true; b.s.bypass = true; b.s.tMask = 0; bad = 0; b.run (SR, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (bad == 0, "bypass beats the gate (%d)", bad);
    // gate + loop together
    Rig g; g.s.bpm = 120; g.s.loopBeats = 0.5; g.s.tOn = true; g.s.tStepBeats = 0.125; g.s.tDuty = 0.5f; g.run (SR * 2); g.s.loopOn = true;
    float pk = 0; bool fin = true; g.run (SR * 2, [&] (long, float, float out) { pk = std::fmax (pk, std::fabs (out)); if (! std::isfinite (out)) fin = false; });
    CHECK (fin && pk > 0.05f && g.e.state() == Engine::LOOP, "loop + gate: peak %.3f state %d", (double) pk, (int) g.e.state());
}

static void testSampleRates()
{
    std::printf ("other sample rates\n");
    for (double sr : { 22050.0, 48000.0, 96000.0 })
    {
        Engine e; CHECK (e.prepare (sr), "prepare %g", sr);
        Settings s; s.hold = true; std::vector<float> a (256, 0.25f), o (256);
        for (int i = 0; i < 2000; ++i) e.process (a.data(), a.data(), o.data(), o.data(), 256, s);
        CHECK (e.state() == Engine::GRAB, "state at %g", sr);
    }
}


// ================================================================ SAMPLE source (deck)
// The record is a ramp rec[k] = (k + 1) * 1e-5, so the output value tells which record frame the needle is on.
struct DeckRig
{
    Engine e; Settings s; std::vector<float> rec, in, out; long t = 0;
    float inLevel = 0.f;                       // constant input (the "beat") level
    explicit DeckRig (long frames = (long) (SR * 4))
    {
        e.prepare (SR); rec.resize (frames); for (long k = 0; k < frames; ++k) rec[k] = (float) ((k + 1) * 1e-5);
        e.setRecord (rec.data(), rec.data(), frames);
        s.deck = true; s.thru = false; s.motorOn = true; in.resize (BLK); out.resize (BLK);
    }
    template <class F> void run (long frames, F f)
    {
        while (frames > 0)
        {
            const int n = frames < BLK ? (int) frames : BLK;
            for (int i = 0; i < n; ++i) in[i] = inLevel;
            e.process (in.data(), in.data(), out.data(), out.data(), n, s);
            for (int i = 0; i < n; ++i) f (t + i, out[i]);
            t += n; frames -= n;
        }
    }
    void run (long frames) { run (frames, [] (long, float) {}); }
    float last() { float v = 0; run (1, [&] (long, float o) { v = o; }); return v; }
};

static void testDeckPlays()
{
    std::printf ("deck: the motor plays the sample forwards at 1x\n");
    DeckRig r;
    r.run (SR * 1);                                                       // spin-up, then full speed
    float a = r.last(); r.run (999); float b = r.last();
    const double steps = (b - a) / 1e-5;
    CHECK (std::fabs (steps - 1000.0) < 2.0, "needle moved %.2f frames in 1000 (1x)", steps);
    CHECK (std::fabs (r.e.deckPosSec() - (float) (r.t / SR)) < 0.5f, "position %.2f s (motor started at 0)", (double) r.e.deckPosSec());
}

static void testDeckMotorStop()
{
    std::printf ("deck: PLAY off brakes the record to a stop (silent), on again picks up\n");
    DeckRig r; r.run (SR * 0.5);
    r.s.motorOn = false; r.run (SR * 1.5);
    float pk = 0; r.run (SR * 0.2, [&] (long, float o) { pk = std::fmax (pk, std::fabs (o)); });
    CHECK (pk < 1e-7f, "stopped record is silent (peak %g)", (double) pk);
    const float pos = r.e.deckPosSec();
    r.run (SR * 0.2);
    CHECK (std::fabs (r.e.deckPosSec() - pos) < 1e-4f, "needle stays put while stopped");
    r.s.motorOn = true; r.run (SR * 0.6);
    float a = r.last(); r.run (99); float b = r.last();
    CHECK (std::fabs ((b - a) / 1e-5 - 100.0) < 1.0, "back at 1x after PLAY (%.2f frames / 100)", (b - a) / 1e-5);
}

static void testDeckEnd()
{
    std::printf ("deck: the record runs out into silence\n");
    DeckRig r ((long) (SR * 0.5)); r.run (SR * 1.5);
    float pk = 0; r.run (SR * 0.2, [&] (long, float o) { pk = std::fmax (pk, std::fabs (o)); });
    CHECK (pk == 0.f && r.e.deckAtEnd(), "silent at the end (peak %g)", (double) pk);
}

static void testDeckCue()
{
    std::printf ("deck: CUE drops the needle at the start (with a short fade, no click)\n");
    DeckRig r; r.run (SR * 1.5);
    float prev = r.last(), maxJump = 0;
    r.e.triggerCue();
    r.run (SR * 0.02, [&] (long, float o) { maxJump = std::fmax (maxJump, std::fabs (o - prev)); prev = o; });
    CHECK (r.e.deckPosSec() < 0.03f, "needle back at the start (%.3f s)", (double) r.e.deckPosSec());
    CHECK (maxJump < 0.01f, "fade: largest sample step %g (the record level is ~0.66 there)", (double) maxJump);
}

static void testDeckScratch()
{
    std::printf ("deck: the platter scratches the sample\n");
    DeckRig r; r.s.inertiaMs = 6.f; r.s.throwSec = 1.f; r.s.motorOn = false;     // a stopped record, a hand on it
    r.run (SR * 1.0);                                                          // let the motor brake to a stop
    r.e.triggerCue(); r.run (SR * 0.05);                                       // needle at 0
    // nothing to play before the start: push forward 0.2 (= 0.2 s), then back 0.1
    for (int k = 1; k <= 10; ++k) { r.s.platter = 0.5f + 0.02f * k; r.run (SR * 0.01); }
    r.run (SR * 0.1);
    CHECK (r.e.state() == Engine::GRAB, "grabbed (state %d)", (int) r.e.state());
    CHECK (std::fabs (r.e.deckPosSec() - 0.2f) < 0.01f, "pushed forward to %.3f s", (double) r.e.deckPosSec());
    float first = -1, lastv = 0; int down = 0, up = 0;
    float prev = r.last();
    for (int k = 1; k <= 10; ++k) { r.s.platter = 0.7f - 0.01f * k; r.run (SR * 0.01, [&] (long, float o) { if (first < 0) first = o; if (o < prev - 1e-9f) ++down; if (o > prev + 1e-9f) ++up; prev = o; lastv = o; }); }
    CHECK (down > up * 4, "pulling back plays the sample backwards (%d down / %d up)", down, up);
    CHECK (std::fabs (r.e.deckPosSec() - 0.1f) < 0.02f, "needle at %.3f s", (double) r.e.deckPosSec());
}

static void testDeckSlipVsVinyl()
{
    std::printf ("deck: release in Slip mode returns to where the record would be; Catch up (vinyl) carries on from the hand\n");
    for (int mode = 0; mode < 2; ++mode)
    {
        DeckRig r; r.s.returnMode = mode; r.s.inertiaMs = 6.f; r.s.releaseSec = 0.1f;
        r.run (SR * 1.0);                                                     // playing, at ~0.9 s
        const float before = r.e.deckPosSec();
        r.s.hold = true; r.run (SR * 0.5); r.s.hold = false;                  // hand on the record for 0.5 s
        r.run (SR * 0.5);
        const float after = r.e.deckPosSec();
        const float expect = mode == 0 ? before + 1.0f : before + 0.5f;       // slip: 1 s of motor time passed; vinyl: the record lost the 0.5 s held
        CHECK (std::fabs (after - expect) < 0.08f, "%s: %.2f s -> %.2f s (expected ~%.2f)", mode == 0 ? "slip" : "vinyl", (double) before, (double) after, (double) expect);
        CHECK (r.e.state() == Engine::LIVE, "back to playing");
    }
}

static void testDeckThruAndEmpty()
{
    std::printf ("deck: THRU mixes the input under the record; no record = input only\n");
    Engine e; e.prepare (SR); Settings s; s.deck = true; s.thru = true;
    std::vector<float> in (BLK), out (BLK); int bad = 0;
    for (int b = 0; b < 100; ++b)
    {
        for (int i = 0; i < BLK; ++i) in[i] = (float) std::sin (0.01 * (b * BLK + i));
        e.process (in.data(), in.data(), out.data(), out.data(), BLK, s);
        for (int i = 0; i < BLK; ++i) if (out[i] != in[i]) ++bad;
    }
    CHECK (bad == 0, "nothing loaded: output == input (%d differ)", bad);
    DeckRig r; r.s.thru = true; r.inLevel = 0.25f; r.s.faderClosed = true;   // the fader cuts the record, not the beat
    r.run (SR * 0.5); const float v = r.last();
    CHECK (std::fabs (v - 0.25f) < 1e-6f, "fader closed: only the input remains (%g)", (double) v);
    r.s.faderClosed = false; r.run (SR * 0.1); const float w = r.last();
    CHECK (w > 0.25f + 0.1f, "fader open: input + record (%g)", (double) w);
}

static void testDeckLoopAndSpin()
{
    std::printf ("deck: loop repeats the record behind the needle; backspin stays inside the record\n");
    DeckRig r; r.s.bpm = 120; r.s.loopBeats = 0.5;                            // 1/8 at 120 = 0.25 s = 11025 frames
    r.run (SR * 1.0);
    r.s.loopOn = true; r.run (SR * 0.05);
    CHECK (r.e.state() == Engine::LOOP, "looping");
    std::vector<float> seg; r.run (11025 * 2, [&] (long, float o) { seg.push_back (o); });
    int diff = 0; for (int k = 0; k < 11025 - 200; ++k) if (std::fabs (seg[k] - seg[k + 11025]) > 1e-6f) ++diff;
    CHECK (diff == 0, "the loop repeats every 11025 frames (%d differ)", diff);
    r.s.loopOn = false; r.run (SR * 0.1);
    CHECK (r.e.state() == Engine::LIVE, "loop off: back to the record");
    DeckRig q; q.s.spinSpeed = 16; q.s.spinSec = 4;
    q.run (SR * 0.3); q.e.triggerBackspin();
    bool finite = true; q.run (SR * 3, [&] (long, float o) { if (! std::isfinite (o)) finite = false; });
    CHECK (finite && q.e.deckPosSec() >= 0.f, "backspin past the start: finite, needle %.2f s", (double) q.e.deckPosSec());
    DeckRig z; z.run (SR * 0.01); z.s.loopOn = true; z.run (BLK);
    CHECK (z.e.loopFailed() && z.e.state() != Engine::LOOP, "loop at the very start: refused (not enough played)");
}

static void testDeckModeSwitch()
{
    std::printf ("switching source back to live is transparent again\n");
    DeckRig r; r.s.thru = true; r.run (SR * 0.3);
    r.s.deck = false;
    Rig live; (void) live;
    std::vector<float> in (BLK), out (BLK); int bad = 0;
    for (int b = 0; b < 50; ++b)
    {
        for (int i = 0; i < BLK; ++i) in[i] = (float) (0.3 * std::sin (0.02 * (b * BLK + i)));
        r.e.process (in.data(), in.data(), out.data(), out.data(), BLK, r.s);
        for (int i = 0; i < BLK; ++i) if (out[i] != in[i]) ++bad;
    }
    CHECK (bad == 0, "live again: output == input (%d differ)", bad);
}

// ================================================================ the motor on the live input
struct SineRig
{
    Engine e; Settings s; long t = 0; double hz = 440.0; std::vector<float> in, out, allIn, allOut;
    SineRig() { e.prepare (SR); in.resize (BLK); out.resize (BLK); }
    void run (long frames)
    {
        while (frames > 0)
        {
            const int n = frames < BLK ? (int) frames : BLK;
            for (int i = 0; i < n; ++i) in[i] = (float) (0.5 * std::sin (2 * M_PI * hz * (double) (t + i) / SR));
            e.process (in.data(), in.data(), out.data(), out.data(), n, s);
            allIn.insert (allIn.end(), in.begin(), in.begin() + n); allOut.insert (allOut.end(), out.begin(), out.begin() + n);
            t += n; frames -= n;
        }
    }
    size_t mark() const { return allOut.size(); }
    float peak (size_t a, size_t b) const { float p = 0; for (size_t i = a; i < b && i < allOut.size(); ++i) p = std::fmax (p, std::fabs (allOut[i])); return p; }
    bool exact (size_t a, size_t b) const { for (size_t i = a; i < b && i < allOut.size(); ++i) if (allOut[i] != allIn[i]) return false; return true; }
    double freq (size_t a, size_t b) const { int c = 0; for (size_t i = a + 1; i < b && i < allOut.size(); ++i) if (allOut[i - 1] <= 0 && allOut[i] > 0) ++c; return c / ((double) (b - a) / SR); }
};

static void testLiveStopStart()
{
    std::printf ("live: STOP winds the incoming audio down to silence; START spins up and slips back to live\n");
    for (int mode = 0; mode < 2; ++mode)
    {
        SineRig r; r.s.returnMode = mode; r.s.stopSec = 0.5f; r.s.startSec = 0.3f;
        r.run (SR * 1);
        CHECK (r.exact (0, r.mark()), "transparent before");
        r.s.motorOn = false; size_t m0 = r.mark(); r.run (SR * 0.25);
        const double f = r.freq (m0 + (size_t) (0.1 * SR), m0 + (size_t) (0.2 * SR));
        CHECK (f < 400.0 && f > 150.0, "winding down: pitch falls (%.0f Hz from 440)", f);
        r.run (SR * 0.5); size_t m1 = r.mark(); r.run (SR * 0.5);
        CHECK (r.peak (m1, r.mark()) < 1e-6f, "stopped: silent (peak %g)", (double) r.peak (m1, r.mark()));
        CHECK (r.e.state() == Engine::PLAY && r.e.behindSec() > 0.5f, "stopped record is %.2f s behind the live input", (double) r.e.behindSec());
        r.s.motorOn = true; r.run (SR * 0.3 + (mode == 1 ? SR * 1.0 : 0)); r.run (SR * 0.3);
        size_t m2 = r.mark(); r.run (SR * 0.5);
        CHECK (r.e.state() == Engine::LIVE && r.exact (m2, r.mark()), "%s: back to the live input, bit-exact", mode == 0 ? "slip" : "catch up");
    }
}

static void testLivePitch()
{
    std::printf ("live: pitch down plays slower and falls behind; pitch up can only reach 'now'; back to 0 = live again\n");
    SineRig r; r.run (SR * 1);
    r.s.speed = 0.92; r.run (SR * 0.2); size_t a = r.mark(); r.run (SR * 0.5);
    const double f = r.freq (a, r.mark());
    CHECK (std::fabs (f - 440.0 * 0.92) < 6.0, "-8%%: %.0f Hz (expected %.0f)", f, 440.0 * 0.92);
    CHECK (std::fabs (r.e.behindSec() - 0.056f) < 0.02f, "fell %.3f s behind in 0.7 s", (double) r.e.behindSec());
    r.s.speed = 1.0; r.run (SR * 0.3); size_t b = r.mark(); r.run (SR * 0.3);
    CHECK (r.e.state() == Engine::LIVE && r.exact (b, r.mark()), "pitch back to 0: live again");
    r.s.speed = 1.08; r.run (SR * 0.2); size_t c = r.mark(); r.run (SR * 0.5);
    const double g = r.freq (c, r.mark());
    CHECK (std::fabs (g - 440.0) < 4.0 && r.e.behindSec() < 0.001f, "+8%% at 'now': stays on the live signal (%.0f Hz)", g);
}

static void testLiveReverse()
{
    std::printf ("live: REVERSE plays the history backwards\n");
    Rig r; r.run (SR * 2);
    r.s.reverse = true; r.run (SR * 1.5);                                         // stop time + start time to turn around
    float prev = 0; int down = 0, up = 0; bool first = true;
    r.run (SR * 0.2, [&] (long, float, float o) { if (! first) { if (o < prev) ++down; else if (o > prev) ++up; } prev = o; first = false; });
    CHECK (down > 50 * up, "the ramp plays backwards (%d down, %d up)", down, up);
    CHECK (r.e.motorSpeed() == -1.f, "motor at -1x");
    bool fin = true; r.run (SR * 12, [&] (long, float, float o) { if (! std::isfinite (o)) fin = false; });     // past the end of the history
    CHECK (fin, "running out of history: still finite");
    r.s.reverse = false; r.run (SR * 1.5);
    int bad = 0; r.run (SR * 0.2, [&] (long, float in, float o) { if (in != o) ++bad; });
    CHECK (bad == 0 && r.e.state() == Engine::LIVE, "forward again: live (%d differ)", bad);
}

static void testSlipmatRelease()
{
    std::printf ("letting go with the motor stopped: the record stays still (silent); with the motor at -8%% it plays on at -8%%\n");
    Rig r; r.s.motorOn = false; r.s.stopSec = 0.2f; r.run (SR * 2);
    r.s.hold = true; r.run (SR * 0.2); r.s.hold = false; r.run (SR * 0.5);
    float pk = 0; r.run (SR * 0.2, [&] (long, float, float o) { pk = std::fmax (pk, std::fabs (o)); });
    CHECK (r.e.state() == Engine::PLAY && pk < 1e-6f, "state %d, peak %g", (int) r.e.state(), (double) pk);
    SineRig q; q.s.speed = 0.92; q.run (SR * 1);
    q.s.hold = true; q.run (SR * 0.2); q.s.hold = false; q.run (SR * 0.3);
    size_t a = q.mark(); q.run (SR * 0.4);
    CHECK (q.e.state() == Engine::PLAY && std::fabs (q.freq (a, q.mark()) - 405.0) < 8.0, "released into the motor: %.0f Hz", q.freq (a, q.mark()));
}

static void testMotionAndRing()
{
    std::printf ("rotation readout and the history size\n");
    Rig r; r.run (BLK); (void) r.e.takeMotion(); r.run (BLK * 10);
    CHECK (std::fabs (r.e.takeMotion() - BLK * 10) < 1e-6, "live at 1x: the record turns 1 frame per frame");
    r.s.motorOn = false; r.s.stopSec = 0.1f; r.run (SR * 0.5); (void) r.e.takeMotion(); r.run (SR * 0.2);
    CHECK (std::fabs (r.e.takeMotion()) < 1e-6, "stopped: no rotation");
    Engine e; e.setRingSeconds (30); e.prepare (48000);
    CHECK (e.ringSize() >= 30u * 48000u && e.ringSize() < 60u * 48000u + 65536u, "30 s at 48 kHz: %u frames", e.ringSize());
    float* m = (float*) calloc ((size_t) 1 << 17, 2 * sizeof (float));
    float* old = e.adoptRing (m, 1u << 17);
    CHECK (old != nullptr && e.ringSize() == (1u << 17), "adopted a new ring (History changed)");
    free (old);
    std::vector<float> in (BLK), out (BLK); Settings s; int bad = 0;
    for (int k = 0; k < 2000; ++k)
    {
        for (int i = 0; i < BLK; ++i) in[i] = (float) (0.3 * std::sin (0.01 * (k * BLK + i)));
        e.process (in.data(), in.data(), out.data(), out.data(), BLK, s);
        for (int i = 0; i < BLK; ++i) if (out[i] != in[i]) ++bad;
    }
    CHECK (bad == 0, "after the swap: live audio passes bit-exact (%d differ)", bad);
}

static void testDeckMotor()
{
    std::printf ("deck: pitch and reverse move the needle at the motor speed\n");
    DeckRig r; r.s.speed = 1.08; r.run (SR * 1);
    float a = r.last(); r.run (999); float b = r.last();
    CHECK (std::fabs ((b - a) / 1e-5 - 1080.0) < 3.0, "+8%%: %.1f frames per 1000", (b - a) / 1e-5);
    r.s.speed = 1.0; r.s.reverse = true; r.run (SR * 2);
    a = r.last(); r.run (999); b = r.last();
    CHECK (std::fabs ((b - a) / 1e-5 + 1000.0) < 3.0, "reverse: %.1f frames per 1000", (b - a) / 1e-5);
}

static void testHandTakesLoop()
{
    std::printf ("the hand takes the record out of a loop, seamlessly, from where the loop was playing\n");
    Rig r; r.s.bpm = 120; r.s.loopBeats = 0.5; r.run (SR * 2);
    r.s.loopOn = true; r.run (SR * 0.4);
    CHECK (r.e.state() == Engine::LOOP, "looping");
    float prev = 0, maxStep = 0; bool first = true;
    r.s.platter = 0.49f;                                                       // the hand moves
    r.run (BLK * 2, [&] (long, float, float o) { if (! first) maxStep = std::fmax (maxStep, std::fabs (o - prev)); prev = o; first = false; });
    CHECK (r.e.state() == Engine::GRAB && r.e.takeHandTookLoop(), "grabbed out of the loop (state %d)", (int) r.e.state());
    CHECK (maxStep < 0.01f, "no jump in the sound (largest step %g on a ramp)", (double) maxStep);
    CHECK (! r.e.takeHandTookLoop(), "reported once");
}

static void testPitchShift()
{
    std::printf ("SHIFT pitch on live input: the pitch moves instantly, the sound stays on 'now', 0%% is bit-exact again\n");
    for (double ratio : { 1.08, 0.92, 1.5, 0.5 })
    {
        SineRig r; r.run (SR * 0.5);
        r.s.shiftRatio = ratio; r.run (SR * 0.2);
        size_t a = r.mark(); r.run (SR * 1.0);
        const double f = r.freq (a, r.mark());
        CHECK (std::fabs (f / (440.0 * ratio) - 1.0) < 0.02, "x%.2f: %.1f Hz (expected %.1f)", ratio, f, 440.0 * ratio);
        CHECK (r.e.state() == Engine::LIVE && r.e.behindSec() < 0.001f, "no drift: still live after a second");
        float pk = r.peak (a, r.mark());
        CHECK (pk > 0.4f && pk < 0.62f, "level kept (peak %.2f)", (double) pk);
        r.s.shiftRatio = 1.0; r.run (SR * 0.1); size_t b = r.mark(); r.run (SR * 0.3);
        CHECK (r.exact (b, r.mark()), "back to 0%%: bit-exact");
    }
    std::printf ("scratching works on top of the shifted pitch, and the fader closes the output to silence\n");
    SineRig q; q.s.shiftRatio = 1.1; q.s.inertiaMs = 6.f; q.run (SR * 1);
    for (int k = 1; k <= 10; ++k) { q.s.platter = 0.5f - 0.02f * k; q.run (SR * 0.01); }
    CHECK (q.e.state() == Engine::GRAB, "grabbed (state %d)", (int) q.e.state());
    q.s.faderClosed = true; q.run (SR * 0.05); size_t c = q.mark(); q.run (SR * 0.2);
    CHECK (q.peak (c, q.mark()) == 0.f, "fader closed: exact silence (what the MPC records)");
}

int main()
{
    testPassthrough(); testSilenceWhenHeld(); testBackAndForth(); testSlipReturn(); testCatchUp(); testBackspin(); testChopAndFader();
    testLoop(); testTransformer(); testBoundsAndFinite(); testSampleRates();
    testDeckPlays(); testDeckMotorStop(); testDeckEnd(); testDeckCue(); testDeckScratch(); testDeckSlipVsVinyl(); testDeckThruAndEmpty();
    testDeckLoopAndSpin(); testDeckModeSwitch();
    testLiveStopStart(); testLivePitch(); testLiveReverse(); testSlipmatRelease(); testMotionAndRing(); testDeckMotor(); testHandTakesLoop(); testPitchShift();
    std::printf ("\n%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
